import { Component, OnInit } from '@angular/core';
import { ServiceCallsServiceService } from '../service-calls-service.service';
import { RouterModule, Router } from '@angular/router';
import { ThrowStmt } from '@angular/compiler';
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-reporting-user-component',
  templateUrl: './reporting-user-component.component.html',
  styleUrls: ['./reporting-user-component.component.css']
})
export class ReportingUserComponentComponent implements OnInit {

task: String;
bu: String;
fromDate: String;
toDate: String;
inputValues:  Map<String, String> = new Map<String, String>();

inputValuesTest:  any[] = [];
  reportCategory : String;

  EXCEL_TYPE = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
  EXCEL_EXTENSION = '.xlsx';
  s: any;

  constructor(private service: ServiceCallsServiceService, private router: Router) { }

  ngOnInit(): void {
  }
  
  generateReport(){
     this.inputValues.set("fromDate",this.fromDate);
     this.inputValues.set("toDate",this.toDate);
    this.inputValues.set("bu",this.bu);
     this.inputValues.set("task",this.task);
     console.log(this.inputValues);
    this.service.generateReport(this.inputValues).subscribe((res) => {
      console.log("returned response from java");
        console.log(res);
         for (var index in res) {
          var json = JSON.parse(JSON.stringify(res[index]));
          console.log(json);
          this.inputValuesTest.push(json);
        
        }
        console.log( this.inputValuesTest);
       this.exportAsExcelFile(this.inputValuesTest,'sample');
         },
         err => {
       
         });
        
  }

  exportAsExcelFile(json: any[], excelFileName: string): void {
    const worksheet: XLSX.WorkSheet = XLSX.utils.json_to_sheet(json);
    const workbook: XLSX.WorkBook = { Sheets: { 'data': worksheet }, SheetNames: ['data'] };
    const excelBuffer: any = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
    this.saveAsExcelFile(excelBuffer, excelFileName);
  }

  private saveAsExcelFile(buffer: any, fileName: string): void {
     const data: Blob = new Blob([buffer], {type: this.EXCEL_TYPE});
     FileSaver.saveAs(data, fileName + '_export_' + new  Date().getTime() + this.EXCEL_EXTENSION);
  }


}

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ReportingUserComponentComponent } from './reporting-user-component.component';

describe('ReportingUserComponentComponent', () => {
  let component: ReportingUserComponentComponent;
  let fixture: ComponentFixture<ReportingUserComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ReportingUserComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ReportingUserComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

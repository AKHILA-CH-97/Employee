import { Injectable, SystemJsNgModuleLoader } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject, BehaviorSubject } from 'rxjs';
import { ConstantPool } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class ServiceCallsServiceService {

  constructor(private http: HttpClient) { }

  p = { capId: 'test'};

  insertUserpayload : any;
  validateAdminpayload : any;
  reportUserPayload: any;

   saveUserInMongo(inputValues: any) :Observable<any>{
  // return this.http.get('https://reqres.in/api/users/2');

this.insertUserpayload = {name: inputValues.get("name"), 
            capId: inputValues.get("cap_id"),
            emailId: inputValues.get("emailId"),
            bu: inputValues.get("bu"),
            mentorName: inputValues.get("mentorName"),
            task: inputValues.get("task"),
            project: inputValues.get("project"),
          userType: inputValues.get("userType")};
console.log(this.insertUserpayload);
   return this.http.post('http://localhost:8090/saveUserInfo', this.insertUserpayload);
   }

   url: String;
   validateAdmin(userName,password): Observable<any>{
     console.log(userName);
     console.log(password);
     this.url = 'http://localhost:8090/validateAdmin/'+userName+'/'+password;
     console.log(this.url);
    return this.http.get('http://localhost:8090/validateAdmin/'+userName+'/'+password);
   }

   generateReport(inputValues: any){
    this.reportUserPayload = {fromDate: inputValues.get("fromDate"), 
    toDate: inputValues.get("toDate"),
    bu: inputValues.get("bu"),
    task: inputValues.get("task")}
    return this.http.post('http://localhost:8090/generateReport', this.reportUserPayload);
   }
}

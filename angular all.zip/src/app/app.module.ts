import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EndUserComponentComponent } from './end-user-component/end-user-component.component';
import { ServiceCallsServiceService } from './service-calls-service.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLoginComponentComponent } from './admin-login-component/admin-login-component.component';
import { AdminUserComponentComponent } from './admin-user-component/admin-user-component.component';
import { ReportingUserComponentComponent } from './reporting-user-component/reporting-user-component.component';
import { ReportingLoginComponentComponent } from './reporting-login-component/reporting-login-component.component';


@NgModule({
  declarations: [
    AppComponent,
    EndUserComponentComponent,
    AdminLoginComponentComponent,
    AdminUserComponentComponent,
    ReportingUserComponentComponent,
    ReportingLoginComponentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [ServiceCallsServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }

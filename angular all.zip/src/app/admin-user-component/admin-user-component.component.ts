import { Component, OnInit } from '@angular/core';
import { ServiceCallsServiceService } from '../service-calls-service.service';
import { RouterModule, Router } from '@angular/router';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-admin-user-component',
  templateUrl: './admin-user-component.component.html',
  styleUrls: ['./admin-user-component.component.css']
})
export class AdminUserComponentComponent implements OnInit {

  username: String;
  password: String;
  cap_id: String;
  EmailId: String
  bu: String
  mentorName: String
  task: String
  project: String
  isError: boolean = false;
  userType: String;
  inputValues:  Map<String, String> = new Map<String, String>();

  constructor(private service: ServiceCallsServiceService, private router: Router) { }

  ngOnInit(): void {
  }

  savaDataToMongo(event){
    console.log(event);
    console.log("testtttttt");
    console.log(this.username);
this.inputValues.set("name", this.username);
this.inputValues.set("cap_id", this.cap_id);
this.inputValues.set("emailId", this.EmailId);
this.inputValues.set("bu", this.bu);
this.inputValues.set("mentorName", this.mentorName);
this.inputValues.set("task", this.task);
this.inputValues.set("project", this.project);
this.inputValues.set("userType", this.userType);
console.log(this.inputValues);



    this.service.saveUserInMongo(this.inputValues).subscribe((res) => {
      console.log("returned response from java");
        if(res.message === "success"){
          console.log("entered into res if");
           this.router.navigate(['/about-us']);
         } else{
           console.log("entered into res else");
           this.isError = true;
           this.router.navigate(['/admin-console']);
         }
         },
         err => {
           this.isError = true;
         });
    }
  }


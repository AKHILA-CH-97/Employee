import { TestBed } from '@angular/core/testing';

import { ServiceCallsServiceService } from './service-calls-service.service';

describe('ServiceCallsServiceService', () => {
  let service: ServiceCallsServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServiceCallsServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

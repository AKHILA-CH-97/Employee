import { Component, OnInit, Input } from '@angular/core';
import { ServiceCallsServiceService } from '../service-calls-service.service';
import { RouterModule, Router } from '@angular/router';
import { ThrowStmt } from '@angular/compiler';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-end-user-component',
  templateUrl: './end-user-component.component.html',
  styleUrls: ['./end-user-component.component.css']
})
export class EndUserComponentComponent implements OnInit {

  username: String;
  password: String;
  cap_id: String;
  EmailId: String
  bu: String
  mentorName: String
  task: String
  project: String
  isError: boolean = false;
  inputValues: Map<String, String> = new Map<String, String>();
  endUserForm: FormGroup;

  //priceListMap : Map<String, String> = new Map<String, String>();

  constructor(private service: ServiceCallsServiceService, private router: Router, private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.createEndUserForm();
  }
  /**
   * Creates a new registration form for the user.
   */
  createEndUserForm() {
    this.endUserForm = this.formBuilder.group({
      username: ['', Validators.required],
      cap_id: ['', Validators.required],
      emailId: ['', Validators.email],
      bu: ['', Validators.required],
      project: ['', Validators.required],
      mentorName: ['', Validators.required],
      task: ['', Validators.required]
    });
  }




  savaDataToMongo(event) {
    console.log(event);

    this.inputValues.set("name", this.username);
    this.inputValues.set("cap_id", this.cap_id);
    this.inputValues.set("emailId", this.EmailId);
    this.inputValues.set("bu", this.bu);
    this.inputValues.set("mentorName", this.mentorName);
    this.inputValues.set("task", this.task);
    this.inputValues.set("project", this.project);
    this.inputValues.set("userType", "Super user");
    console.log(this.inputValues);
    this.service.saveUserInMongo(this.inputValues).subscribe((res) => {
      console.log("returned response from java");
      if (res.message === "success") {
        console.log("entered into res if");
        this.isError = true;
        this.router.navigate(['/user-console']);
      } else {
        console.log("entered into res else");
        this.isError = true;
      }
    },
      err => {
        this.isError = true;
      });
  }

  routeTOAdminConsole() {
    //   this.router.navigate["/admin-login"];
    this.router.navigate(["/admin-login"]);
  }

  routeTOReportingConsole() {
    //   this.router.navigate["/admin-login"];
    this.router.navigate(["/reportUser-login"]);
  }



  //  get username() {
  //   return this.endUserForm.get('username');
  // }
  // get cap_id() {
  //   return this.endUserForm.get('cap_id');
  // }
  // get emailId() {
  //   return this.endUserForm.get('emailId');
  // }
  // get bu() {
  //   return this.endUserForm.get('bu');
  // }
  // get project() {
  //   return this.endUserForm.get('project');
  // }
  // get mentorName() {
  //   return this.endUserForm.get('mentorName');
  // }
  // get task() {
  //   return this.endUserForm.get('task');
  // }

}



  // getMongoData(event){
  //   console.log(event);
  //   console.log(this.username);
  //   console.log(this.password);
  //   this.service.saveUserInMongo(this.username,this.password).subscribe((res) => {
  //   console.log("returned response from java");
  //   if(res.message === "success"){
  //     console.log("entered into res if");
  //     this.router.navigate(['/about-us']);
  //   } else{
  //     console.log("entered into res else");
  //     this.isError = true;
  //   }
  //   },
  //   err => {
  //     this.isError = true;
  //   });

  //     }

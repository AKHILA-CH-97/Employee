import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EndUserComponentComponent } from './end-user-component.component';

describe('EndUserComponentComponent', () => {
  let component: EndUserComponentComponent;
  let fixture: ComponentFixture<EndUserComponentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EndUserComponentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EndUserComponentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { ServiceCallsServiceService } from '../service-calls-service.service';
import { RouterModule, Router } from '@angular/router';

@Component({
  selector: 'app-admin-login-component',
  templateUrl: './admin-login-component.component.html',
  styleUrls: ['./admin-login-component.component.css']
})
export class AdminLoginComponentComponent implements OnInit {

  username: String;
  password: String;
  isError: boolean = false;

  constructor(private service: ServiceCallsServiceService, private router: Router) { }

  ngOnInit(): void {
  }

  validatePassword(){
    console.log(this.username);
    this.service.validateAdmin(this.username, this.password).subscribe((res) => {
      console.log("returned response from java");
      console.log(res);
        if(res.message === "success"){
          console.log("entered into res if");
           this.router.navigate(['/admin-console']);
         } else{
           console.log("entered into res else");
           this.isError = true;
           this.router.navigate(['/admin-login']);
         }
         });
  }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EndUserComponentComponent } from './end-user-component/end-user-component.component';
import {AdminLoginComponentComponent } from './admin-login-component/admin-login-component.component';
import { from } from 'rxjs';
import {AdminUserComponentComponent } from './admin-user-component/admin-user-component.component';
import {ReportingUserComponentComponent } from './reporting-user-component/reporting-user-component.component';
import {ReportingLoginComponentComponent } from './reporting-login-component/reporting-login-component.component';
const routes: Routes = [
  {path:"user-console", component: EndUserComponentComponent},
  {path:"admin-login", component: AdminLoginComponentComponent},
  {path:"admin-console", component: AdminUserComponentComponent},
  {path:"reportUser-console", component: ReportingUserComponentComponent},
  {path:"reportUser-login", component: ReportingLoginComponentComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

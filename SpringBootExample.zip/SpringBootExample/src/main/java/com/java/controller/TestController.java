package com.java.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.java.Dao.TestDao;
import com.java.Vo.ReportRespose;
import com.java.Vo.StatusResponse;
import com.mongodb.client.MongoClient;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TestController {

	@Autowired
    private TestDao testDao;

	    @GetMapping(value = "/test", produces = {"application/zip"})
	    @CrossOrigin(origins = "http://localhost:4200")
	    public void getDownloadLicensesStream() throws IOException  {
	    	
	    	//httpResponse.sendRedirect("https://swapi-stage1.cisco.com/software/services/swscfdlsvcs/download/licenses");
	    	System.out.println("working spring boot");
	    }
	
	    
	    @PostMapping(value = "/saveUserInfo")
	    @CrossOrigin(origins = "http://localhost:4200/about-us")
	    public String saveEndUserInfo(@RequestBody Map<String, String> input) {
	    	testDao.insertUserInfoIntoMongo(input);
	    	return "success";
	    }
	    
	    
	    @PostMapping(value = "/generateReport")
	    @CrossOrigin(origins = "http://localhost:4200/about-us")
	    public List<ReportRespose> getReport(@RequestBody Map<String, String> input) throws FileNotFoundException {
	    	List<ReportRespose> response = testDao.generateReport(input);
	    	return response;
	    }
	    
	    @PostMapping(value = "/saveReportUser")
	    @CrossOrigin(origins = "http://localhost:4200/about-us")
	    public String saveReportUser(@RequestBody Map<String, String> input) throws FileNotFoundException {
	    	String response = testDao.saveUser(input);
	    	return response;
	    }
	    
	    @GetMapping(value = "/validateAdmin/{userName}/{password}/{userType}")
	    @CrossOrigin(origins = "http://localhost:4200")
	    public ResponseEntity<StatusResponse> validateAdmin(@PathVariable("userName") String userName, @PathVariable("password") String password
	    		,@PathVariable("userType") String userType) throws IOException  {
	    	StatusResponse response = new StatusResponse();
	    	String res = testDao.validateAdminCred(userName,password,userType);
	    	response.setMessage(res);
	    	return new ResponseEntity<StatusResponse>(response, HttpStatus.OK);
	    }
}

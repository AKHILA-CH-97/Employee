package com.java;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.mongodb.MongoClientURI;
import com.mongodb.MongoClient;

@Configuration
public class MongoConnection {

	@Value("${mongo.db.clientURI}")
	private String mongoUrl;
	
	@Bean   (name="mongoclientdb")
	public MongoClient getMongoClient()  {
		String productDbConn=mongoUrl;
		 return new MongoClient(
	    		    new MongoClientURI(
	    		    		productDbConn));
	}
}
